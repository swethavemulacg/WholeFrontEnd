import { BookingPipePipe } from './booking-pipe.pipe';

describe('BookingPipePipe', () => {
  it('create an instance', () => {
    const pipe = new BookingPipePipe();
    expect(pipe).toBeTruthy();
  });
});
