import { BookingPipe1Pipe } from './booking-pipe1.pipe';

describe('BookingPipe1Pipe', () => {
  it('create an instance', () => {
    const pipe = new BookingPipe1Pipe();
    expect(pipe).toBeTruthy();
  });
});
