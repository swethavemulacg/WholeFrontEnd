import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BookingDetails } from './booking-details';

@Injectable({
  providedIn: 'root'
})
export class BookingServiceService {

   url="http://localhost:1138";
  constructor(private http:HttpClient) { }

  bookingHistory():Observable<any>
  {
    return this.http.get("http://localhost:1138/viewBookingHistory",{responseType:'text'});
  }

  //Non blocking asynchronous data
  bookingHistoryForUser(userId):Observable<any>
  {

    return this.http.get("http://localhost:1138/viewBookingHistoryForUser/"+userId,{responseType:'text'});
  }

  cancellbooking(bookingId):Observable<any>
  {
    return this.http.delete("http://localhost:1138/cancelBooking/"+bookingId,{responseType:'text'});
  }

  searchFlight(from,to):Observable<any>
  {
    return this.http.get("http://localhost:1138/viewFlightsBetweenCities/"+from+"/"+to,{responseType:'text'});
  }

  bookTicket(bookingDetails:BookingDetails,userId:any,airlineId:any):Observable<any>
  { 
    return this.http.post("http://localhost:1138/bookFlight/"+userId+"/"+airlineId,bookingDetails,{responseType:'text'});
  }
}
