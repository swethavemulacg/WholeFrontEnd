import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-refunds',
  templateUrl: './refunds.component.html',
  styleUrls: ['./refunds.component.css']
})
export class RefundsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
