import { FeedbackSearchPipe } from './feedback-search.pipe';

describe('FeedbackSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new FeedbackSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
