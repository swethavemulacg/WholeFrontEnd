import { FlightDetails } from './flight-details';

describe('FlightDetails', () => {
  it('should create an instance', () => {
    expect(new FlightDetails()).toBeTruthy();
  });
});
