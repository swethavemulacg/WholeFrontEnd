export class FlightDetails {

    flightId:number;
    flightFrom:String;
    flightTo:String;
    flightTiming:String;
    ticketCost:number;
}
